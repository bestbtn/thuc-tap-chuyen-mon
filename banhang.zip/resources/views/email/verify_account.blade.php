<p>Cảm ơn bạn đã dùng sản phẩm của chúng tôi</p>
<p>Vui lòng nhấn <a href="{{$route}}">vào đây </a> để xác minh tài khoản</p>
